import os
import sys
import time

#Extract a Version String from single or double quotes. Removes any internal quotes
def getVerString(s):
    l = len(s)
    inq = False
    q = ''
    sb = ''
    i = -1
    for c in s:
        i = i + 1
        if (c == '"' or c == "'") and (not inq or q == c) and not s[i-1:i] == '\\':
            q = c if not inq else ''
            inq = not inq
        elif inq:
            sb = sb + c
        if sb and (not inq or (i+1 == l)):
            sb = sb.replace('\\"', '').replace("\\'", "").replace('\\\\', '\\').replace("'", '').replace('"', '')
            #Scans for "\d+\.\d+" at start of string
            if sb[0:1].isdigit() and '.' in sb:
               parts = sb.replace('-', '.').replace('_', '.').split('.')
               if len(parts) > 1 and parts[0].isdigit() and parts[1].isdigit():
                   return sb
            sb = ''
    return None


s = 'OpenJDK "1.2.A3_55-b45" \'1.20.4".0\''
print(getVerString(s))

s1 = r'"\"'
i = 2
print(s1[i])
print("@" + s1[i-1:i] + "@")
import sys

version_info = sys.version_info
major = version_info.major
minor = version_info.minor
patch = version_info.micro
print(1 if (not major == 2 or minor < 7 or minor == 7 and patch < 15) else 0)
sys.exit(1 if (not major == 2 or minor < 7 or minor == 7 and patch < 15) else 0)